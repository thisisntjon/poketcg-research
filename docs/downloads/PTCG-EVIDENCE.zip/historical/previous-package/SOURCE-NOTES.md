# Source notes for the alternative article

This revision uses existing experiments and a bounded inspection of learner source. No new games or training were run. Numbers [1]–[7] below match the article. The updated evidence archive preserves the previous package under `original-evidence/` and adds selected source excerpts under `new-source-evidence/`.

## [1] Submitted product and competition performance

Original package: `workflow/research/owned-learning-roadmap-20260813/lane-s-c61-provenance-receipt.json` and `workflow/writeup/visuals-2026-09-06/COMPETITION-VERIFICATION.json`.

The policy and deck hashes identify the credited unmodified tetsutani implementation. Score and rank are the September 6 snapshot, not a claim about final standing. The Lucario counter and experimental learner did not produce that submitted score.

## [2] Implemented experimental learner and teacher interface

New excerpts: `model_v2.py.excerpt.txt`, `action_decoder.py.excerpt.txt`, `semantic_encoder.py.excerpt.txt`, `c61_teacher_bridge.py.excerpt.txt`, `lf_v2_policy.py.excerpt.txt`. `SOURCE-MANIFEST.json` records the original file, full-file SHA-256, and line ranges for each excerpt.

- `model_v2.py`: policy recurrence with 256 hidden units; option features linked to source and target entities; sequential selection updates.
- `action_decoder.py`: legal selection without replacement, bounded by minimum/maximum counts, with STOP once the minimum is satisfied.
- `semantic_encoder.py`: actor-visible state projection, excluded hidden serialization, semantic action/context representation and returned menu-index mapping.
- `c61_teacher_bridge.py`: credited public c61 teacher interface, converting actor-visible queries and answers to training selections.
- `lf_v2_policy.py`: runtime recurrence and resets. Policy recurrence carries between decisions; the separate history encoder processes the supplied observation window. No claim that every kind of recurrent state persists identically.

These are inspected implementation claims. Figure 1 illustrates an allowed sequence with minimum one and maximum three: select A, remove A, then choose STOP. It does not represent an observed match or prove optimal subset choice. Known recurrent/behavioral-cloning methods are not claimed as new inventions. Excerpts are explanatory evidence, not a complete runnable software release or a new certification of all runtime paths.

## [3] Earlier August student evaluation

Original package: `workflow/writeup/visuals-2026-09-06/LEARNING-VERIFICATION.json`, plus `learning-evidence/training-receipt.json` and `learning-evidence/screen-receipt.json`.

The records identify the selected August checkpoint (epoch 8; recorded state hash begins `6ef49e2ee697`, checkpoint bytes hash begins `e072ae4c4555`). Its held-out imitation loss improved from 1.072 to 1.042; it won 23 of 1,200 decided games against exact c61 with the same Grimmsnarl deck. Three draws were excluded. These figures do not evaluate the entire current v2 source tree. The article deliberately keeps the historical checkpoint separate from the current design description.

## [4] Deck and mechanics

Original package: `workflow/writeup/visuals-2026-09-06/SOURCE-VERIFICATION.json`, which identifies recovered c61 source, deck and organizer card-data hashes. It supports the submitted 60-card list, Grimmsnarl/Froslass/Munkidori interactions, Alakazam's Powerful Hand and Xerosic's hand reduction.

Additional bounded read: Mega Lucario ex, card ID 678, in that same local `EN_Card_Data.csv` (SHA-256 `a0ea63cf7adcb65d35436ce0eb390de6e2e35654a7c67c065a45f4abaa00f373`). Aura Jab costs one Fighting Energy, deals 130 and can distribute up to three discarded Basic Fighting Energy to Benched Pokémon. Mega Brave costs two Fighting Energy and deals 270; that Pokémon cannot use Mega Brave on its next turn. This is a paraphrase of source card mechanics, not engine execution. Organizer card data and card artwork are not redistributed.

The experimental list's authoritative treatment is the experiment's deck file, not every historical hardcoded list still in a policy module. This draft states the established one-Carmine-to-Xerosic substitution, avoiding unsupported full experimental deck counts. Targeting Abra/Kadabra expresses attack-plan preference and may require bringing a Benched target Active; the article does not claim Lucario directly damages the Bench with these attacks.

## [5] Factorial experiment

Original package: `workflow/research/2026-09-03-xerosic-sniper-factorial.md`, development rows and `workflow/writeup/visuals-2026-09-06/ABLATION-VERIFICATION.json`.

Use each contrast's own batch control and recorded pooling convention: rule-only +3.62 [1.52, 5.72], card-only +5.02 [3.30, 6.75], combined +7.82 [6.08, 9.56]. The development panel contains 40% Alakazam. Rule-only includes two batches; card-only and combined include three. The second host's raw 4,000 rows remain outside the package, as previously disclosed. The four-arm batch's 2,000 games per arm must not be multiplied into an invented total for all comparisons. The data do not establish positive interaction/synergy.

## [6] Opponent results and mixture

Original package: `workflow/research/2026-09-03-strike3-rows.csv` and `workflow/writeup/visuals-2026-09-06/counterplay-data.json`.

Figures 2 and 3 are newly drawn from the same recorded cell estimates and variance values. No new data or replication is implied. Scores use win 1/draw 0.5/loss 0. Normal 95% intervals assume independent games, arms and opponent cells and condition on those fixed implementations. The mixture uses equal weights within two groups. It does not include uncertainty about metagame share or unseen opponents; it is not a deployment threshold. All seven opponent cells are shown.

## [7] Research records and continuing objective

Original package: `workflow/knowledge-register/README.md`. New excerpt: `architecture.md.excerpt.txt`, from the August 13 `workflow/WINNING-STRATEGY-ARCHITECTURE.md`, whose identity is ratified by the repository's current START-HERE. The historic design document credits prior learning systems and describes intended loops; it does not prove their completion.

The article states the role of recorded research without claiming complete fresh-worker recovery. Repeated retained improvement remains the next objective. Jon's current instructions explicitly confirm his intention to continue beyond this competition.

## Package scope

PTCG-EVIDENCE.zip preserves the prior evidence members under original-evidence/ and adds these notes and the selected learner excerpts. START-HERE.md and EVIDENCE-GUIDE.md provide entry routes; PACKAGE-MANIFEST.json covers current members. The former manifest remains scoped to the original evidence. Current figures and the matching article are supplied outside this ZIP in the update folder. Full training weights, external-host raw rows, full inventory tooling and organizer materials are not included. This is selected evidence, not a one-command end-to-end reproduction.
