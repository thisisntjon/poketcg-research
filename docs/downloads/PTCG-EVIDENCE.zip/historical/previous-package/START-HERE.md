# Evidence for the revised article

Start with EVIDENCE-GUIDE.md, then SOURCE-NOTES.md for references [1]-[7]. Original records are under original-evidence/; new implementation excerpts under new-source-evidence/. The original manifest covers its original files only. PACKAGE-MANIFEST.json covers this archive. Current article/figures are supplied separately.
