# Evidence guide

From Research Agents to Better Pokémon TCG Decisions

Jonathan Simone

## How to use this evidence

Read FINAL-REPORT.pdf for the article. Open PTCG-EVIDENCE.zip and start with START-HERE.md, then SOURCE-NOTES.md. Reference numbers [1]-[7] in the article follow the routes below. Original evidence files are under original-evidence/; the added learner excerpts are under new-source-evidence/.

## Reference map

**[1] Submitted product and dated performance.** original-evidence/workflow/research/owned-learning-roadmap-20260813/lane-s-c61-provenance-receipt.json identifies the credited unmodified public submission. original-evidence/workflow/writeup/visuals-2026-09-06/COMPETITION-VERIFICATION.json records its September 6 score and rank.

**[2] Experimental learner design.** new-source-evidence/ contains model_v2.py, action_decoder.py, semantic_encoder.py, c61_teacher_bridge.py and lf_v2_policy.py excerpts. SOURCE-MANIFEST.json gives full-source hashes and selected line ranges. These support implementation descriptions, not a completed competitive improvement cycle. Figure 1 is an illustrative selection sequence.

**[3] Earlier student evaluation.** Under original-evidence/workflow/writeup/visuals-2026-09-06/, LEARNING-VERIFICATION.json and learning-evidence/ contain training and game-comparison receipts. The August checkpoint won 23 of 1,200 decided games against c61; that result does not evaluate the entire current v2 implementation.

**[4] Deck and mechanics.** SOURCE-VERIFICATION.json in the same visuals directory records the recovered submitted deck and card-mechanics sources. SOURCE-NOTES.md adds the bounded Mega Lucario ex mechanics inspection. Organizer card data and artwork are not redistributed.

**[5] Card-and-policy factorial.** original-evidence/workflow/research/2026-09-03-xerosic-sniper-factorial.md and the associated development CSV describe the experiment. ABLATION-VERIFICATION.json in the visuals directory records the comparisons. The second host's raw rows are not included; SOURCE-NOTES.md explains the pooled-result boundary.

**[6] Opponent panel and mixture.** original-evidence/workflow/research/2026-09-03-strike3-rows.csv contains 8,400 game rows. counterplay-data.json in the visuals directory contains cell estimates and variances. Figures 2 and 3 use this same data, with win 1, draw 0.5 and loss 0. The mixture plot is a derived sensitivity analysis, not another experiment.

**[7] Research memory and future architecture.** original-evidence/workflow/knowledge-register/README.md describes the research-memory interface. new-source-evidence/architecture.md.excerpt.txt records the intended learning architecture. A completed cycle of repeated retained improvement remains a future objective.

## Scope and reproducibility

The submitted public c61 agent, the experimental recurrent learner, and the modified public-derived Lucario pilot are distinct artifacts. Their scores and capabilities should not be combined. The new source excerpts document design; the historical checkpoint receipts document a particular experiment.

The original evidence members are preserved unchanged under their named subdirectory. Its historical figures and descriptions remain provenance; the current article and figures accompany this guide outside the evidence ZIP. The original manifest applies only to the original evidence. PACKAGE-MANIFEST.json identifies all current archive members.

This is selected evidence, not a complete runnable project. Training weights, one development host's raw rows, full inventory tooling and organizer materials are not included. No new training or gameplay was performed for the revision. The updated article, guide and selected source evidence have matching reference numbers.
